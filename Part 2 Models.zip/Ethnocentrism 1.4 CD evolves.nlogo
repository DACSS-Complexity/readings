turtles-own [ PTR cooperate-with-same? cooperate-with-different? ]
                                           ;; agents probability to reproduce; two key elements of strategy

to setup                                   ;; *** NEW create a world ONLY all egoists or all altruists
  ca
  ask patches [ ifelse DD-start? [create-defectors ] [create-cooperators]]
  reset-ticks
end

to create-defectors                        ;; NEW create only egoists
  sprout 1 [
    set color random-color                 ;; defined below
    set cooperate-with-same? false
    set cooperate-with-different? false
    update-shape                           ;; agent's shape reflect its strategy
  ]
end

to create-cooperators                      ;; NEW create only altruists
    sprout 1 [
    set color random-color                 ;; defined below
    set cooperate-with-same? true
    set cooperate-with-different? true
    update-shape                           ;; agent's shape reflect its strategy
  ]
end

to create-turtle
  sprout 1 [
    set color random-color                 ;; defined below

    set cooperate-with-same? (random-float 1.0 < immigrant-chance-cooperate-with-same)
                                   ;; probabilistically set strategy for interacting with same color agent

    set cooperate-with-different? (random-float 1.0 < immigrant-chance-cooperate-with-different)
                                   ;; probabilistically set strategy for interacting with different color agent

    update-shape                           ;; agent's shape reflect its strategy
  ]
end

to-report random-color
  report one-of [red blue yellow green]    ;; randomly choose one of those four colors
end

to go
  immigrate
  ask turtles [ set PTR initial-PTR ]      ;; ****NB**** reset probability to reproduce to starting value
  ask turtles [ interact ]                 ;; all agents interact with others if they can
  ask turtles [ reproduce ]                ;; they reproduce, using their ***post-interaction*** PTR
  death                                    ;; kill some agents at random; ****NB**** NOT based on fitness (PTR)
  my-update-plots
  tick
end

to immigrate                                ;; new agents enter the world on random empty cells
  let empty-patches patches with [not any? turtles-here]
  let how-many min list immigrants-per-day (count empty-patches)
                                            ;; can't have more immigrants than empty patches
                                            ;; how-many immigrants there are is the lesser of:
                                            ;; immigrants-per-day, the number of empty patches
  ask n-of how-many empty-patches [ create-turtle ]
                                            ;;  "how-many" random empty patches each create a new agent
end

to interact                                 ;; ***** NB: the (clever) key routine where the PD game is played
                                            ;; agents interact with others in their Von Neumann neighborhood.
                                            ;; NB! commands inside the ASK are written from the perspective
                                            ;; of the agent being interacted with. To refer back to the agent
                                            ;; that initiated the interaction, we use the MYSELF primitive.

             ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
             ;;
             ;; *****ML NOTE. This code does NOT, contrary to superficial impressions, result in the game
             ;; being played twice by a given agent pair. Think of the calling agent as the row player and
             ;; each of the four agents on neighbors4 as column players in the 2*2 representation of the PD
             ;; Game payoffs arise from a combination of "costs of giving" and "gains from receiving".
             ;; These are built in two passes.
             ;;
             ;; FIRST PASS: I am the calling agent (row player) and "giver". I pay giving costs for each opponent
             ;; on neighbors4 I give to. Each of these receivers (column players) gets the gain of receiving
             ;; I pay no giving cost for each opponent I don't give to, and each of these gets zero.
             ;;
             ;; SECOND PASS: I am one of four opponents (column player) and "receiver" on neighbors4 of another
             ;; calling agent I get the gain of receiving if the calling agent gives to me, and zero if not.
             ;;
             ;; After the two passes, I have paid any costs of giving and received any gains of receiving
             ;;
             ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


  ask turtles-on neighbors4 [

    if color = [color] of myself
      [if [cooperate-with-same?] of myself [
         ask myself [ set PTR PTR - cost-of-giving ]    ;; I pay
         set PTR PTR + gain-of-receiving]]              ;; neighbors gain

             ;; Note the nested "ifs". Payoffs only distributed above if my
             ;; neighbor is same color AND I cooperate with same; else zero.

             ;; Similarly, if we are different colors, if I cooperate with agents
             ;; of different color I reduce my PTR and reward my neighbors

    if color != [color] of myself [
      if [cooperate-with-different?] of myself [
        ask myself [ set PTR PTR - cost-of-giving ]
        set PTR PTR + gain-of-receiving]]
  ]
             ;; The net effect after all interactions is a PD game with the
             ;; mutual defection PTR payoff normalised to zero
end


;; use PTR to determine if the agent gets to reproduce
;; ********ML NOTE This is the replicator part of the replicator-mutator system

to reproduce                                ;; Agents use post-interaction PTR as probability they reproduce
  if random-float 1.0 < PTR [
    let destination one-of neighbors4 with [not any? turtles-here]
    if destination != nobody [              ;; Agent can only reproduce if a von-Neuman patch is empty
      hatch 1 [                             ;; Hatch a clone of the current turtle in the new location
        move-to destination
        mutate                              ;; then mutate the child
      ]
    ]
  ]
end

;; modify the children of agents according to the mutation rate
;; ********ML NOTE This is the mutator part of the replicator-mutator system

to mutate                                   ;; children mutate according to the mutation rate
                                            ;; first mutate the color
  if random-float 1.0 < mutation-rate [
    let old-color color
    while [color = old-color]
      [ set color random-color ]            ;; MAKE the color change; NB not just give a chance to change
  ]
                                            ;; now mutate the strategy variables, using NOT to toggle them
  if random-float 1.0 < mutation-rate [
    set cooperate-with-same? not cooperate-with-same?
  ]
  if random-float 1.0 < mutation-rate [
    set cooperate-with-different? not cooperate-with-different?
  ]
  update-shape                              ;; make sure the shape of the agent reflects its new strategy
end

to death                                    ;; kill turtle with probability death-rate
  ask turtles [
    if random-float 1.0 < death-rate [ die ]
  ]
end

to update-shape                             ;; make sure shape matches strategy (using nested ifelse)
                                            ;; if agent cooperates with same they are a circle

  ifelse cooperate-with-same? [
    ifelse cooperate-with-different?
      [ set shape "circle" ]                ;; filled in circle (altruist)
      [ set shape "circle 2" ]              ;; empty circle (ethnocentric)
  ]
                                            ;; if agent doesn't cooperate with same they are a square
  [
    ifelse cooperate-with-different?
      [ set shape "square" ]                ;; filled in square (cosmopolitan)
      [ set shape "square 2" ]              ;; empty square (egoist)
  ]
end
                                            ;; ML some useful reporters
to-report cc_prop
   report count turtles with [shape = "circle"] / count turtles
end

to-report cd_prop
   report count turtles with [shape = "circle 2"] / count turtles
end

to-report dc_prop
   report count turtles with [shape = "square"] / count turtles
end

to-report dd_prop
   report count turtles with [shape = "square 2"] / count turtles
end

to my-update-plots                           ;; boilerplate plot management
  set-current-plot-pen "CC"  ;; altruists
  plotxy ticks count turtles with [shape = "circle"]
  set-current-plot-pen "CD"  ;; ethnocentric
  plotxy ticks count turtles with [shape = "circle 2"]
  set-current-plot-pen "DC"  ;; cosmopolitans
  plotxy ticks count turtles with [shape = "square"]
  set-current-plot-pen "DD"  ;; selfish
  plotxy ticks count turtles with [shape = "square 2"]
end



; Copyright 2003 Uri Wilensky. All rights reserved.
; The full copyright notice is in the Information tab.

; Edited by Michael Laver in 2016 to reduce clutter and re-commented to increase transparenecy
@#$#@#$#@
GRAPHICS-WINDOW
342
33
809
501
-1
-1
9.0
1
10
1
1
1
0
1
1
1
0
50
0
50
1
1
1
ticks
30.0

SLIDER
5
150
171
183
mutation-rate
mutation-rate
0.0
1.0
0.005
0.0010
1
NIL
HORIZONTAL

SLIDER
5
184
171
217
death-rate
death-rate
0.0
1.0
0.1
0.05
1
NIL
HORIZONTAL

SLIDER
5
218
171
251
immigrants-per-day
immigrants-per-day
0.0
100.0
1.0
1.0
1
NIL
HORIZONTAL

SLIDER
172
150
318
183
initial-PTR
initial-PTR
0.0
1.0
0.12
0.01
1
NIL
HORIZONTAL

SLIDER
172
184
318
217
cost-of-giving
cost-of-giving
0.0
1.0
0.01
0.01
1
NIL
HORIZONTAL

SLIDER
172
218
318
251
gain-of-receiving
gain-of-receiving
0.0
1.0
0.03
0.01
1
NIL
HORIZONTAL

BUTTON
34
19
121
52
setup
setup
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
120
19
202
52
NIL
go
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

PLOT
6
323
318
525
Strategy Counts
time
count
0.0
10.0
0.0
1.0
true
true
"" ""
PENS
"CC" 1.0 0 -10899396 true "" ""
"CD" 1.0 0 -2674135 true "" ""
"DC" 1.0 0 -4079321 true "" ""
"DD" 1.0 0 -16777216 true "" ""

SLIDER
5
252
318
285
immigrant-chance-cooperate-with-same
immigrant-chance-cooperate-with-same
0.0
1.0
0.5
0.01
1
NIL
HORIZONTAL

SLIDER
5
286
318
319
immigrant-chance-cooperate-with-different
immigrant-chance-cooperate-with-different
0.0
1.0
0.5
0.01
1
NIL
HORIZONTAL

TEXTBOX
35
64
275
126
Circles cooperate with same color\nSquares defect with same color\nFilled-in shapes cooperate with different color\nEmpty shapes defect with different color\n
11
0.0
0

SWITCH
217
19
313
52
DD-start?
DD-start?
1
1
-1000

@#$#@#$#@
## WHAT IS IT?


This is a version of the Ethnocentrism model in the NetLogo models library, edited by Michael Laver in 2019 to reduce clutter and re-commented to increase transparency. 

This version of the model maintains the original "hyper-local" definition of ethnocentrim and the baseline model parameterization, but starts all simulatons with a world populated either only by egoists, all playing DD, or only by alruists, all playing CC. Starting with no ethnocentrtic agents whatsoever, random mutation and immigration enable the emergence of a dominant population of ethnocentric agents. Theoretically, this is a more striking result than those derived from the baseline model.

For citation information, see the Info tab for Ethnocentrism 1.0
@#$#@#$#@
default
true
0
Polygon -7500403 true true 150 5 40 250 150 205 260 250

airplane
true
0
Polygon -7500403 true true 150 0 135 15 120 60 120 105 15 165 15 195 120 180 135 240 105 270 120 285 150 270 180 285 210 270 165 240 180 180 285 195 285 165 180 105 180 60 165 15

arrow
true
0
Polygon -7500403 true true 150 0 0 150 105 150 105 293 195 293 195 150 300 150

box
false
0
Polygon -7500403 true true 150 285 285 225 285 75 150 135
Polygon -7500403 true true 150 135 15 75 150 15 285 75
Polygon -7500403 true true 15 75 15 225 150 285 150 135
Line -16777216 false 150 285 150 135
Line -16777216 false 150 135 15 75
Line -16777216 false 150 135 285 75

bug
true
0
Circle -7500403 true true 96 182 108
Circle -7500403 true true 110 127 80
Circle -7500403 true true 110 75 80
Line -7500403 true 150 100 80 30
Line -7500403 true 150 100 220 30

butterfly
true
0
Polygon -7500403 true true 150 165 209 199 225 225 225 255 195 270 165 255 150 240
Polygon -7500403 true true 150 165 89 198 75 225 75 255 105 270 135 255 150 240
Polygon -7500403 true true 139 148 100 105 55 90 25 90 10 105 10 135 25 180 40 195 85 194 139 163
Polygon -7500403 true true 162 150 200 105 245 90 275 90 290 105 290 135 275 180 260 195 215 195 162 165
Polygon -16777216 true false 150 255 135 225 120 150 135 120 150 105 165 120 180 150 165 225
Circle -16777216 true false 135 90 30
Line -16777216 false 150 105 195 60
Line -16777216 false 150 105 105 60

car
false
0
Polygon -7500403 true true 300 180 279 164 261 144 240 135 226 132 213 106 203 84 185 63 159 50 135 50 75 60 0 150 0 165 0 225 300 225 300 180
Circle -16777216 true false 180 180 90
Circle -16777216 true false 30 180 90
Polygon -16777216 true false 162 80 132 78 134 135 209 135 194 105 189 96 180 89
Circle -7500403 true true 47 195 58
Circle -7500403 true true 195 195 58

circle
false
0
Circle -7500403 true true 0 0 300

circle 2
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240

cow
false
0
Polygon -7500403 true true 200 193 197 249 179 249 177 196 166 187 140 189 93 191 78 179 72 211 49 209 48 181 37 149 25 120 25 89 45 72 103 84 179 75 198 76 252 64 272 81 293 103 285 121 255 121 242 118 224 167
Polygon -7500403 true true 73 210 86 251 62 249 48 208
Polygon -7500403 true true 25 114 16 195 9 204 23 213 25 200 39 123

cylinder
false
0
Circle -7500403 true true 0 0 300

dot
false
0
Circle -7500403 true true 90 90 120

face happy
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 255 90 239 62 213 47 191 67 179 90 203 109 218 150 225 192 218 210 203 227 181 251 194 236 217 212 240

face neutral
false
0
Circle -7500403 true true 8 7 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Rectangle -16777216 true false 60 195 240 225

face sad
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 168 90 184 62 210 47 232 67 244 90 220 109 205 150 198 192 205 210 220 227 242 251 229 236 206 212 183

fish
false
0
Polygon -1 true false 44 131 21 87 15 86 0 120 15 150 0 180 13 214 20 212 45 166
Polygon -1 true false 135 195 119 235 95 218 76 210 46 204 60 165
Polygon -1 true false 75 45 83 77 71 103 86 114 166 78 135 60
Polygon -7500403 true true 30 136 151 77 226 81 280 119 292 146 292 160 287 170 270 195 195 210 151 212 30 166
Circle -16777216 true false 215 106 30

flag
false
0
Rectangle -7500403 true true 60 15 75 300
Polygon -7500403 true true 90 150 270 90 90 30
Line -7500403 true 75 135 90 135
Line -7500403 true 75 45 90 45

flower
false
0
Polygon -10899396 true false 135 120 165 165 180 210 180 240 150 300 165 300 195 240 195 195 165 135
Circle -7500403 true true 85 132 38
Circle -7500403 true true 130 147 38
Circle -7500403 true true 192 85 38
Circle -7500403 true true 85 40 38
Circle -7500403 true true 177 40 38
Circle -7500403 true true 177 132 38
Circle -7500403 true true 70 85 38
Circle -7500403 true true 130 25 38
Circle -7500403 true true 96 51 108
Circle -16777216 true false 113 68 74
Polygon -10899396 true false 189 233 219 188 249 173 279 188 234 218
Polygon -10899396 true false 180 255 150 210 105 210 75 240 135 240

house
false
0
Rectangle -7500403 true true 45 120 255 285
Rectangle -16777216 true false 120 210 180 285
Polygon -7500403 true true 15 120 150 15 285 120
Line -16777216 false 30 120 270 120

leaf
false
0
Polygon -7500403 true true 150 210 135 195 120 210 60 210 30 195 60 180 60 165 15 135 30 120 15 105 40 104 45 90 60 90 90 105 105 120 120 120 105 60 120 60 135 30 150 15 165 30 180 60 195 60 180 120 195 120 210 105 240 90 255 90 263 104 285 105 270 120 285 135 240 165 240 180 270 195 240 210 180 210 165 195
Polygon -7500403 true true 135 195 135 240 120 255 105 255 105 285 135 285 165 240 165 195

line
true
0
Line -7500403 true 150 0 150 300

line half
true
0
Line -7500403 true 150 0 150 150

pentagon
false
0
Polygon -7500403 true true 150 15 15 120 60 285 240 285 285 120

person
false
0
Circle -7500403 true true 110 5 80
Polygon -7500403 true true 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Rectangle -7500403 true true 127 79 172 94
Polygon -7500403 true true 195 90 240 150 225 180 165 105
Polygon -7500403 true true 105 90 60 150 75 180 135 105

plant
false
0
Rectangle -7500403 true true 135 90 165 300
Polygon -7500403 true true 135 255 90 210 45 195 75 255 135 285
Polygon -7500403 true true 165 255 210 210 255 195 225 255 165 285
Polygon -7500403 true true 135 180 90 135 45 120 75 180 135 210
Polygon -7500403 true true 165 180 165 210 225 180 255 120 210 135
Polygon -7500403 true true 135 105 90 60 45 45 75 105 135 135
Polygon -7500403 true true 165 105 165 135 225 105 255 45 210 60
Polygon -7500403 true true 135 90 120 45 150 15 180 45 165 90

square
false
0
Rectangle -7500403 true true 30 30 270 270

square 2
false
0
Rectangle -7500403 true true 30 30 270 270
Rectangle -16777216 true false 60 60 240 240

star
false
0
Polygon -7500403 true true 151 1 185 108 298 108 207 175 242 282 151 216 59 282 94 175 3 108 116 108

target
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240
Circle -7500403 true true 60 60 180
Circle -16777216 true false 90 90 120
Circle -7500403 true true 120 120 60

tree
false
0
Circle -7500403 true true 118 3 94
Rectangle -6459832 true false 120 195 180 300
Circle -7500403 true true 65 21 108
Circle -7500403 true true 116 41 127
Circle -7500403 true true 45 90 120
Circle -7500403 true true 104 74 152

triangle
false
0
Polygon -7500403 true true 150 30 15 255 285 255

triangle 2
false
0
Polygon -7500403 true true 150 30 15 255 285 255
Polygon -16777216 true false 151 99 225 223 75 224

truck
false
0
Rectangle -7500403 true true 4 45 195 187
Polygon -7500403 true true 296 193 296 150 259 134 244 104 208 104 207 194
Rectangle -1 true false 195 60 195 105
Polygon -16777216 true false 238 112 252 141 219 141 218 112
Circle -16777216 true false 234 174 42
Rectangle -7500403 true true 181 185 214 194
Circle -16777216 true false 144 174 42
Circle -16777216 true false 24 174 42
Circle -7500403 false true 24 174 42
Circle -7500403 false true 144 174 42
Circle -7500403 false true 234 174 42

turtle
true
0
Polygon -10899396 true false 215 204 240 233 246 254 228 266 215 252 193 210
Polygon -10899396 true false 195 90 225 75 245 75 260 89 269 108 261 124 240 105 225 105 210 105
Polygon -10899396 true false 105 90 75 75 55 75 40 89 31 108 39 124 60 105 75 105 90 105
Polygon -10899396 true false 132 85 134 64 107 51 108 17 150 2 192 18 192 52 169 65 172 87
Polygon -10899396 true false 85 204 60 233 54 254 72 266 85 252 107 210
Polygon -7500403 true true 119 75 179 75 209 101 224 135 220 225 175 261 128 261 81 224 74 135 88 99

wheel
false
0
Circle -7500403 true true 3 3 294
Circle -16777216 true false 30 30 240
Line -7500403 true 150 285 150 15
Line -7500403 true 15 150 285 150
Circle -7500403 true true 120 120 60
Line -7500403 true 216 40 79 269
Line -7500403 true 40 84 269 221
Line -7500403 true 40 216 269 79
Line -7500403 true 84 40 221 269

x
false
0
Polygon -7500403 true true 270 75 225 30 30 225 75 270
Polygon -7500403 true true 30 75 75 30 270 225 225 270
@#$#@#$#@
NetLogo 6.0.2
@#$#@#$#@
setup-full repeat 150 [ go ]
@#$#@#$#@
@#$#@#$#@
<experiments>
  <experiment name="experiment 7 burn in default settings" repetitions="8" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="20000"/>
    <metric>cc_prop</metric>
    <metric>cd_prop</metric>
    <metric>dc_prop</metric>
    <metric>dd_prop</metric>
    <enumeratedValueSet variable="initial-PTR">
      <value value="0.12"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="immigrant-chance-cooperate-with-same">
      <value value="0.5"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="cost-of-giving">
      <value value="0.01"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="immigrant-chance-cooperate-with-different">
      <value value="0.5"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="gain-of-receiving">
      <value value="0.03"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="immigrants-per-day">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="death-rate">
      <value value="0.1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mutation-rate">
      <value value="0.005"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="experiment 8 all DD or CC start" repetitions="8" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="2000"/>
    <metric>cc_prop</metric>
    <metric>cd_prop</metric>
    <metric>dc_prop</metric>
    <metric>dd_prop</metric>
    <enumeratedValueSet variable="immigrants-per-day">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="immigrant-chance-cooperate-with-different">
      <value value="0.5"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="gain-of-receiving">
      <value value="0.03"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="initial-PTR">
      <value value="0.12"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="DD-start?">
      <value value="false"/>
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="cost-of-giving">
      <value value="0.01"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mutation-rate">
      <value value="0.005"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="death-rate">
      <value value="0.1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="immigrant-chance-cooperate-with-same">
      <value value="0.5"/>
    </enumeratedValueSet>
  </experiment>
</experiments>
@#$#@#$#@
@#$#@#$#@
default
0.0
-0.2 0 0.0 1.0
0.0 1 1.0 0.0
0.2 0 0.0 1.0
link direction
true
0
Line -7500403 true 150 150 90 180
Line -7500403 true 150 150 210 180
@#$#@#$#@
0
@#$#@#$#@
