;;____________________________________
;;
;;      SETUP AND HOUSEKEEPING
;;____________________________________

breed [citizens citizen]                          ; citizens have endogenous ideal points
breed [hardliners hardliner]                      ; hardliners do not

globals [
a0 a1                                             ; n of agents with position 0 or 1 on cleavage a
b0 b1                                             ; n of agents with position 0 or 1 on cleavage b
]

turtles-own [
cleavage-a cleavage-b                             ; agent's group on cleavages a and  b
subgroup                                          ; agent's 2 x 2 subgroup
peer                                              ; "who" of agent identified as peer for interaction
]

to setup
   clear-all
   ask patches [set pcolor white]
   create-citizens n-pop [setxy random-xcor random-ycor]

   ;; assign agents to categories 0 or 1 on cleavages a and b
   ;; proportions in each category on each cleavage read from the interface
   ;; xc, set on the interface, is the association between cleavage positions
   ;; xc = 0, perfect reinforcing; xc = 0.5, maximum cross-cutting

   set a0 round (cleavage-a-mean * n-pop)
   set a1 n-pop - a0
   set b0 round (cleavage-b-mean * n-pop)
   set b1 n-pop - b0

   ask citizens [set cleavage-a 0]
   ask n-of a1 citizens [set cleavage-a 1]

   ask citizens with  [cleavage-a = 0] [set cleavage-b 0]
   ask n-of (a0 * xc) citizens with [cleavage-a = 0] [set cleavage-b 1]
   ask citizens with  [cleavage-a = 1] [set cleavage-b 1]
   ask n-of (a1 * xc) citizens with [cleavage-a = 1] [set cleavage-b 0]

  ; assign subgroups and colors
   ask citizens   [
                 if (cleavage-a = 1 and cleavage-b = 1) [set subgroup 11 set color blue]
                 if (cleavage-a = 1 and cleavage-b = 0) [set subgroup 10 set color cyan]
                 if (cleavage-a = 0 and cleavage-b = 1) [set subgroup 01 set color pink]
                 if (cleavage-a = 0 and cleavage-b = 0) [set subgroup 00 set color red]
                 ]

  ;; turn prop-hard citizens into hardliners and give them clustered locations that depend on their cleavage-a group
   ask n-of round(prop-hard * n-pop) citizens [set breed hardliners biased-scatter set shape "person" set size 2 ]
   reset-ticks
end

to biased-scatter                                       ; hardliner positions are normally distributed with sd 5
  ifelse cleavage-a = 0                                 ; around a mean of (+/-) hard-bias on each dimension
         [setxy random-normal hard-bias 5 random-normal hard-bias 5]
         [setxy random-normal (-1 * hard-bias) 5 random-normal (-1 * hard-bias) 5]
end

;;____________________________________
;;
;;      RUNTIME PROCEDURES
;;____________________________________

to go
   ask citizens [
     set peer one-of other turtles                                         ;; ALL CITIZENS choose random other AGENT as peer
                                                                           ;; NB voters mingle but hardliners can be peers
     if ([cleavage-a] of peer = [cleavage-a] of self and [cleavage-b] of peer = [cleavage-b] of self) [interact]
                                                                           ;; if both a and b categories are the same, always interact
     if ([cleavage-a] of peer = [cleavage-a] of self and [cleavage-b] of peer != [cleavage-b] of self)
        [if (random-float 1 < outgroup-openness) [interact]]               ;; if peer is in the same category on a but not on b
                                                                           ;; interact with probability outgroup-openness
     if ([cleavage-a] of peer != [cleavage-a] of self and [cleavage-b] of peer = [cleavage-b] of self)
        [if (random-float 1 < outgroup-openness) [interact]]               ;; if peer is in the same category on b but not on a
                                                                           ;; interact with probability outgroup-opennes
     if ([cleavage-a] of peer != [cleavage-a] of self and [cleavage-b] of peer != [cleavage-b] of self)
        [if (random-float 1 < outgroup-openness ^ 2 ) [interact]]          ;; if peer is in the same category on neither a nor b
     ]                                                                     ;; interact with probability outgroup-open-a ^ 2

    tick
end

to interact
  set heading random-float 360
  forward reaction                                                         ;; first jump distance "reaction" in a random direction
  face peer                                                                ;; then move towards peer by "attraction" proportion of your distance from the peer
  forward distance peer * attraction                                       ;; for a constant reaction, attraction gives the bais towards the peer
end

;;________________________
;;
;;    REPORTERS
;;________________________

to-report polarization                                                    ;; polarization normed by polarization of hardliners
  let x0 mean [xcor] of turtles with [cleavage-a = 0]
  let y0 mean [ycor] of turtles with [cleavage-a = 0]
  let x1 mean [xcor] of turtles with [cleavage-a = 1]
  let y1 mean [ycor] of turtles with [cleavage-a = 1]
  let norm sqrt ((2 * hard-bias) ^ 2 + (2 * hard-bias) ^ 2)
  report sqrt ((x0 - x1) ^ 2 + (y0 - y1) ^ 2 ) / norm
end

to-report dom-polarization                                                ;; polarization of non-cross-cut subgroups
  let x00 mean [xcor] of turtles with [subgroup = 00]                     ;; normed by polarization of hardliners
  let y00 mean [ycor] of turtles with [subgroup = 00]
  let x11 mean [xcor] of turtles with [subgroup = 11]
  let y11 mean [ycor] of turtles with [subgroup = 11]
  let norm sqrt ((2 * hard-bias) ^ 2 + (2 * hard-bias) ^ 2)
  report sqrt ((x00 - x11) ^ 2 + (y00 - y11) ^ 2 ) / norm
end

to-report nondom-polarization                                             ;; polarization of cross-cut subgroups
  let x01 mean [xcor] of turtles with [subgroup = 01]                     ;; normed by polarization of hardliners
  let y01 mean [ycor] of turtles with [subgroup = 01]
  let x10 mean [xcor] of turtles with [subgroup = 10]
  let y10 mean [ycor] of turtles with [subgroup = 10]
  let norm sqrt ((2 * hard-bias) ^ 2 + (2 * hard-bias) ^ 2)
  report sqrt ((x01 - x10) ^ 2 + (y01 - y10) ^ 2 ) / norm
end
@#$#@#$#@
GRAPHICS-WINDOW
230
10
753
534
-1
-1
6.36
1
10
1
1
1
0
0
0
1
-40
40
-40
40
0
0
1
ticks
30.0

SLIDER
27
76
194
109
cleavage-a-mean
cleavage-a-mean
0.1
.9
0.5
.05
1
NIL
HORIZONTAL

SLIDER
27
108
194
141
cleavage-b-mean
cleavage-b-mean
0
1
0.5
.05
1
NIL
HORIZONTAL

BUTTON
25
10
88
43
NIL
setup
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

SLIDER
26
43
194
76
n-pop
n-pop
0
1000
500.0
1
1
NIL
HORIZONTAL

MONITOR
55
408
112
453
10
count turtles with [subgroup = 10]
3
1
11

MONITOR
110
408
167
453
11
count turtles with [subgroup = 11]
3
1
11

SLIDER
27
140
194
173
xc
xc
0
0.5
0.5
.01
1
NIL
HORIZONTAL

TEXTBOX
58
345
152
363
Cleavage crosstab
11
0.0
1

SLIDER
27
178
194
211
outgroup-openness
outgroup-openness
0
1
0.08
.01
1
NIL
HORIZONTAL

BUTTON
87
10
194
43
NIL
go
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

SLIDER
27
243
194
276
attraction
attraction
0
100
0.1
.01
1
NIL
HORIZONTAL

SLIDER
27
273
194
306
reaction
reaction
0
10
2.0
1
1
NIL
HORIZONTAL

SLIDER
26
305
195
338
prop-hard
prop-hard
0
.20
0.05
.01
1
NIL
HORIZONTAL

MONITOR
55
494
167
539
NIL
nondom-polarization
3
1
11

SLIDER
27
210
194
243
hard-bias
hard-bias
0
25
20.0
1
1
NIL
HORIZONTAL

MONITOR
55
451
167
496
NIL
dom-polarization
3
1
11

MONITOR
55
364
112
409
00
count turtles with [subgroup = 00]
3
1
11

MONITOR
110
364
167
409
01
count turtles with [subgroup = 01]
3
1
11

MONITOR
55
536
167
581
NIL
polarization
3
1
11

@#$#@#$#@
## WHAT IS IT?

A model of the evolution of public opinion with cross-cutting groupd memberships, discussed in full in Chapter 4 of "Agent based models of social life: Part 2 digging deeper" published by Cambridge University Press.


## CREDITS AND REFERENCES

Original model code by Michael Laver
Copyright Michael Laver 2019
@#$#@#$#@
default
true
0
Polygon -7500403 true true 150 5 40 250 150 205 260 250

airplane
true
0
Polygon -7500403 true true 150 0 135 15 120 60 120 105 15 165 15 195 120 180 135 240 105 270 120 285 150 270 180 285 210 270 165 240 180 180 285 195 285 165 180 105 180 60 165 15

arrow
true
0
Polygon -7500403 true true 150 0 0 150 105 150 105 293 195 293 195 150 300 150

box
false
0
Polygon -7500403 true true 150 285 285 225 285 75 150 135
Polygon -7500403 true true 150 135 15 75 150 15 285 75
Polygon -7500403 true true 15 75 15 225 150 285 150 135
Line -16777216 false 150 285 150 135
Line -16777216 false 150 135 15 75
Line -16777216 false 150 135 285 75

bug
true
0
Circle -7500403 true true 96 182 108
Circle -7500403 true true 110 127 80
Circle -7500403 true true 110 75 80
Line -7500403 true 150 100 80 30
Line -7500403 true 150 100 220 30

butterfly
true
0
Polygon -7500403 true true 150 165 209 199 225 225 225 255 195 270 165 255 150 240
Polygon -7500403 true true 150 165 89 198 75 225 75 255 105 270 135 255 150 240
Polygon -7500403 true true 139 148 100 105 55 90 25 90 10 105 10 135 25 180 40 195 85 194 139 163
Polygon -7500403 true true 162 150 200 105 245 90 275 90 290 105 290 135 275 180 260 195 215 195 162 165
Polygon -16777216 true false 150 255 135 225 120 150 135 120 150 105 165 120 180 150 165 225
Circle -16777216 true false 135 90 30
Line -16777216 false 150 105 195 60
Line -16777216 false 150 105 105 60

car
false
0
Polygon -7500403 true true 300 180 279 164 261 144 240 135 226 132 213 106 203 84 185 63 159 50 135 50 75 60 0 150 0 165 0 225 300 225 300 180
Circle -16777216 true false 180 180 90
Circle -16777216 true false 30 180 90
Polygon -16777216 true false 162 80 132 78 134 135 209 135 194 105 189 96 180 89
Circle -7500403 true true 47 195 58
Circle -7500403 true true 195 195 58

circle
false
0
Circle -7500403 true true 0 0 300

circle 2
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240

cow
false
0
Polygon -7500403 true true 200 193 197 249 179 249 177 196 166 187 140 189 93 191 78 179 72 211 49 209 48 181 37 149 25 120 25 89 45 72 103 84 179 75 198 76 252 64 272 81 293 103 285 121 255 121 242 118 224 167
Polygon -7500403 true true 73 210 86 251 62 249 48 208
Polygon -7500403 true true 25 114 16 195 9 204 23 213 25 200 39 123

cylinder
false
0
Circle -7500403 true true 0 0 300

dot
false
0
Circle -7500403 true true 90 90 120

face happy
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 255 90 239 62 213 47 191 67 179 90 203 109 218 150 225 192 218 210 203 227 181 251 194 236 217 212 240

face neutral
false
0
Circle -7500403 true true 8 7 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Rectangle -16777216 true false 60 195 240 225

face sad
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 168 90 184 62 210 47 232 67 244 90 220 109 205 150 198 192 205 210 220 227 242 251 229 236 206 212 183

fish
false
0
Polygon -1 true false 44 131 21 87 15 86 0 120 15 150 0 180 13 214 20 212 45 166
Polygon -1 true false 135 195 119 235 95 218 76 210 46 204 60 165
Polygon -1 true false 75 45 83 77 71 103 86 114 166 78 135 60
Polygon -7500403 true true 30 136 151 77 226 81 280 119 292 146 292 160 287 170 270 195 195 210 151 212 30 166
Circle -16777216 true false 215 106 30

flag
false
0
Rectangle -7500403 true true 60 15 75 300
Polygon -7500403 true true 90 150 270 90 90 30
Line -7500403 true 75 135 90 135
Line -7500403 true 75 45 90 45

flower
false
0
Polygon -10899396 true false 135 120 165 165 180 210 180 240 150 300 165 300 195 240 195 195 165 135
Circle -7500403 true true 85 132 38
Circle -7500403 true true 130 147 38
Circle -7500403 true true 192 85 38
Circle -7500403 true true 85 40 38
Circle -7500403 true true 177 40 38
Circle -7500403 true true 177 132 38
Circle -7500403 true true 70 85 38
Circle -7500403 true true 130 25 38
Circle -7500403 true true 96 51 108
Circle -16777216 true false 113 68 74
Polygon -10899396 true false 189 233 219 188 249 173 279 188 234 218
Polygon -10899396 true false 180 255 150 210 105 210 75 240 135 240

house
false
0
Rectangle -7500403 true true 45 120 255 285
Rectangle -16777216 true false 120 210 180 285
Polygon -7500403 true true 15 120 150 15 285 120
Line -16777216 false 30 120 270 120

leaf
false
0
Polygon -7500403 true true 150 210 135 195 120 210 60 210 30 195 60 180 60 165 15 135 30 120 15 105 40 104 45 90 60 90 90 105 105 120 120 120 105 60 120 60 135 30 150 15 165 30 180 60 195 60 180 120 195 120 210 105 240 90 255 90 263 104 285 105 270 120 285 135 240 165 240 180 270 195 240 210 180 210 165 195
Polygon -7500403 true true 135 195 135 240 120 255 105 255 105 285 135 285 165 240 165 195

line
true
0
Line -7500403 true 150 0 150 300

line half
true
0
Line -7500403 true 150 0 150 150

pentagon
false
0
Polygon -7500403 true true 150 15 15 120 60 285 240 285 285 120

person
false
0
Circle -7500403 true true 110 5 80
Polygon -7500403 true true 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Rectangle -7500403 true true 127 79 172 94
Polygon -7500403 true true 195 90 240 150 225 180 165 105
Polygon -7500403 true true 105 90 60 150 75 180 135 105

plant
false
0
Rectangle -7500403 true true 135 90 165 300
Polygon -7500403 true true 135 255 90 210 45 195 75 255 135 285
Polygon -7500403 true true 165 255 210 210 255 195 225 255 165 285
Polygon -7500403 true true 135 180 90 135 45 120 75 180 135 210
Polygon -7500403 true true 165 180 165 210 225 180 255 120 210 135
Polygon -7500403 true true 135 105 90 60 45 45 75 105 135 135
Polygon -7500403 true true 165 105 165 135 225 105 255 45 210 60
Polygon -7500403 true true 135 90 120 45 150 15 180 45 165 90

square
false
0
Rectangle -7500403 true true 30 30 270 270

square 2
false
0
Rectangle -7500403 true true 30 30 270 270
Rectangle -16777216 true false 60 60 240 240

star
false
0
Polygon -7500403 true true 151 1 185 108 298 108 207 175 242 282 151 216 59 282 94 175 3 108 116 108

target
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240
Circle -7500403 true true 60 60 180
Circle -16777216 true false 90 90 120
Circle -7500403 true true 120 120 60

tree
false
0
Circle -7500403 true true 118 3 94
Rectangle -6459832 true false 120 195 180 300
Circle -7500403 true true 65 21 108
Circle -7500403 true true 116 41 127
Circle -7500403 true true 45 90 120
Circle -7500403 true true 104 74 152

triangle
false
0
Polygon -7500403 true true 150 30 15 255 285 255

triangle 2
false
0
Polygon -7500403 true true 150 30 15 255 285 255
Polygon -16777216 true false 151 99 225 223 75 224

truck
false
0
Rectangle -7500403 true true 4 45 195 187
Polygon -7500403 true true 296 193 296 150 259 134 244 104 208 104 207 194
Rectangle -1 true false 195 60 195 105
Polygon -16777216 true false 238 112 252 141 219 141 218 112
Circle -16777216 true false 234 174 42
Rectangle -7500403 true true 181 185 214 194
Circle -16777216 true false 144 174 42
Circle -16777216 true false 24 174 42
Circle -7500403 false true 24 174 42
Circle -7500403 false true 144 174 42
Circle -7500403 false true 234 174 42

turtle
true
0
Polygon -10899396 true false 215 204 240 233 246 254 228 266 215 252 193 210
Polygon -10899396 true false 195 90 225 75 245 75 260 89 269 108 261 124 240 105 225 105 210 105
Polygon -10899396 true false 105 90 75 75 55 75 40 89 31 108 39 124 60 105 75 105 90 105
Polygon -10899396 true false 132 85 134 64 107 51 108 17 150 2 192 18 192 52 169 65 172 87
Polygon -10899396 true false 85 204 60 233 54 254 72 266 85 252 107 210
Polygon -7500403 true true 119 75 179 75 209 101 224 135 220 225 175 261 128 261 81 224 74 135 88 99

wheel
false
0
Circle -7500403 true true 3 3 294
Circle -16777216 true false 30 30 240
Line -7500403 true 150 285 150 15
Line -7500403 true 15 150 285 150
Circle -7500403 true true 120 120 60
Line -7500403 true 216 40 79 269
Line -7500403 true 40 84 269 221
Line -7500403 true 40 216 269 79
Line -7500403 true 84 40 221 269

x
false
0
Polygon -7500403 true true 270 75 225 30 30 225 75 270
Polygon -7500403 true true 30 75 75 30 270 225 225 270
@#$#@#$#@
NetLogo 6.0.2
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
<experiments>
  <experiment name="experiment 1 burn in" repetitions="8" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="20000"/>
    <metric>nondom-polarization</metric>
    <metric>dom-polarization</metric>
    <enumeratedValueSet variable="cleavage-a-mean">
      <value value="0.5"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="attraction">
      <value value="0.1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="hard-bias">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="outgroup-openness">
      <value value="0.05"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="prop-hard">
      <value value="0.05"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="n-pop">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reaction">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="cleavage-b-mean">
      <value value="0.5"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="xc">
      <value value="0.05"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="experiment 2 polarization by xc" repetitions="100" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="2000"/>
    <metric>nondom-polarization</metric>
    <metric>dom-polarization</metric>
    <enumeratedValueSet variable="cleavage-a-mean">
      <value value="0.5"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="attraction">
      <value value="0.1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="hard-bias">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="outgroup-openness">
      <value value="0.05"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="prop-hard">
      <value value="0.05"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="n-pop">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reaction">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="cleavage-b-mean">
      <value value="0.5"/>
    </enumeratedValueSet>
    <steppedValueSet variable="xc" first="0" step="0.05" last="0.5"/>
  </experiment>
  <experiment name="experiment 3 polarization by XC and prop hard" repetitions="25" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="2000"/>
    <metric>nondom-polarization</metric>
    <metric>dom-polarization</metric>
    <enumeratedValueSet variable="prop-hard">
      <value value="0.02"/>
      <value value="0.05"/>
      <value value="0.08"/>
    </enumeratedValueSet>
    <steppedValueSet variable="xc" first="0" step="0.05" last="0.5"/>
    <enumeratedValueSet variable="cleavage-a-mean">
      <value value="0.5"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="attraction">
      <value value="0.1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="hard-bias">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="outgroup-openness">
      <value value="0.05"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="n-pop">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reaction">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="cleavage-b-mean">
      <value value="0.5"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="experiment 4 polarization by XC and outgroup openness" repetitions="25" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="2000"/>
    <metric>polarization</metric>
    <metric>nondom-polarization</metric>
    <metric>dom-polarization</metric>
    <enumeratedValueSet variable="outgroup-openness">
      <value value="0.02"/>
      <value value="0.05"/>
      <value value="0.08"/>
    </enumeratedValueSet>
    <steppedValueSet variable="xc" first="0" step="0.05" last="0.5"/>
    <enumeratedValueSet variable="cleavage-a-mean">
      <value value="0.5"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="attraction">
      <value value="0.1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="hard-bias">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="prop-hard">
      <value value="0.05"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="n-pop">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reaction">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="cleavage-b-mean">
      <value value="0.5"/>
    </enumeratedValueSet>
  </experiment>
</experiments>
@#$#@#$#@
@#$#@#$#@
default
0.0
-0.2 0 0.0 1.0
0.0 1 1.0 0.0
0.2 0 0.0 1.0
link direction
true
0
Line -7500403 true 150 150 90 180
Line -7500403 true 150 150 210 180
@#$#@#$#@
0
@#$#@#$#@
